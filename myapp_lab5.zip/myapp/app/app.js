
// Importing required modules
const express = require('express');
const mongoose = require('mongoose');
const redis = require('redis');

// Create a client for Redis
const client = redis.createClient({ host: process.env.REDIS_HOST });

// Connect to MongoDB
mongoose.connect(process.env.MONGO_URL, { useNewUrlParser: true, useUnifiedTopology: true, authSource: 'admin' })
  .then(() => console.log('MongoDB connected'))
  .catch(err => console.error('MongoDB connection error:', err));

// Define a Mongoose schema for the Product document
const ProductSchema = mongoose.Schema({
  name: String,
  description: String,
  price: Number
});

// Create a Mongoose model for the Product document in 'product' collection
const Product = mongoose.model('product', ProductSchema, 'product');

// Create an express application
const app = express();
app.use(express.json());  // Enable parsing of json request bodies

// Define a route for handling POST requests to create a new product
app.post('/product', (req, res) => {
  const newProduct = new Product({ name: req.body.name, description: req.body.description, price: req.body.price });
  newProduct.save()
    .then(doc => res.json(doc))
    .catch(err => res.status(500).json({ message: 'Error inserting document:', err }));
});

// Define a route for handling GET requests to retrieve all products
app.get('/products', (req, res) => {
  Product.find({})
    .then(docs => res.json(docs))
    .catch(err => res.status(500).json({ message: 'Error retrieving documents:', err }));
});

// Define a route for handling GET requests to retrieve a product by ID
app.get('/product/:id', (req, res) => {
  Product.findById(req.params.id)
    .then(doc => res.json(doc))
    .catch(err => res.status(500).json({ message: 'Error retrieving document:', err }));
});

// Define a route for handling PUT requests to update a specific product
app.put('/product/:id', (req, res) => {
  Product.findByIdAndUpdate(req.params.id, req.body, {new: true}) // "new: true" returns the updated document
    .then(doc => res.json(doc))
    .catch(err => res.status(500).json({ message: 'Error updating document:', err }));
});

// Define a route for handling DELETE requests to delete a specific product
app.delete('/product/:id', (req, res) => {
  Product.findByIdAndDelete(req.params.id)
    .then(doc => res.json(doc))
    .catch(err => res.status(500).json({ message: 'Error deleting document:', err }));
});

// Define a route for caculating the average price of the  products
app.get('/products/avg-price', (req, res) => {
  Product.aggregate([{ $group: { _id: null, avgPrice: { $avg: "$price" } } }])
    .then(result => res.json(result))
    .catch(err => res.status(500).json({ message: 'Error aggregating documents:', err }));
});

// Define route to calculate average price of products that cost > 50
app.get('/products/avg-price-over-50', (req, res) => {
  Product.aggregate([
    { $match: { price: { $gt: 50 } } },
    { $group: { _id: null, avgPrice: { $avg: "$price" } } }
  ])
    .then(result => res.json(result))
    .catch(err => res.status(500).json({ message: 'Error aggregating documents:', err }));
});

// Start the express application
app.listen(3000, () => console.log('App listening on port 3000'));
