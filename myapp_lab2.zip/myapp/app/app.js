const express = require('express');
const mongoose = require('mongoose');
const redis = require('redis');

const app = express();
const client = redis.createClient({
    host: process.env.REDIS_HOST
});

client.on('connect', () => {
    console.log('Connected to Redis');
});

client.on('error', err => {
    console.log('Redis error: ', err);
});

mongoose.connect(process.env.MONGO_URL, { useNewUrlParser: true, useUnifiedTopology: true })
    .then(() => console.log('MongoDB connected...'))
    .catch(err => console.error(err));

app.get('/', (req, res) => {
    res.send("Welcome to MongoDB Redis class.");
});

app.get('/redis', (req, res) => {
    let counter;
    client.get('counter', function(err, reply) {
        if(reply) {
            counter = reply;
        } else {
            counter = 1;
        }
        client.set('counter', ++counter);
        res.json({counter: counter});
    });
});

app.get('/mongodb', (req, res) => {
    const mongoClient = mongoose.mongo.MongoClient;
    mongoClient.connect(process.env.MONGO_URL, {authSource: 'admin'}, function(err, client) {
        const adminDb = client.db('admin').admin();
        adminDb.listDatabases(function(err, dbs) {
            res.json({databases: dbs});
            client.close();
        });
    });
});

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`Server running on port ${port}`));
